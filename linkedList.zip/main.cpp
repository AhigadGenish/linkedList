#include "List.h"
// Ahigad Genish
// Ahigad.genish@gmail.com


void main()
{
	Student anyStudent1("anyStudent1", "111111111", 96);
	Student anyStudent2("anyStudent2", "222222222", 73);
	Student anyStudent3("anyStudent3", "333333333", 67);
	Student anyStudent4("anyStudent4", "444444444", 81);
	Student anyStudent5("anyStudent5", "555555555", 73);
	Student anyStudent6("anyStudent6", "666666666", 91);
	Student anyStudent7("anyStudent7", "777777777", 85);
	

	List newList;

	newList.insertFirst(anyStudent1);
	newList.insertLast(anyStudent2);
	newList.insertLast(anyStudent3);
	newList.insertFirst(anyStudent4);
	newList.insertFirst(anyStudent6);
	cout << " **** Before Sort ****" << endl;
	newList.printList();
	newList.sortListByGpa();
	cout << "**** After sort ****" << endl;
	newList.printList();
	newList.insertSortedByGpa(anyStudent5);
	newList.insertSortedByGpa(anyStudent7);
	newList.removeNode("444444444");
	cout << "**** After insertSorted ****" << endl;
	newList.printList();
	
	
	return;

}
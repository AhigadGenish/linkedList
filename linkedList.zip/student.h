#include <string>
#include <iostream>
#pragma once
using namespace std;

class Student
{
	string _name;
	string _id;
	int _gpa;
public:
	//getters.
	string getName() const
	{return this->_name;}
	string getId() const 
	{return this->_id;}
	int getGpa() const
	{return this->_gpa;}
	//setters and constructors.
	void setName(string name);
	void setId(string id);
	void setGpa(int grade);
	void setStudent(string name, string id,int grade);
	Student(const Student& student);
	Student(string name = "AnyName", string id = "000000000", int grade = 0) :_name(name), _id(id), _gpa(grade) {}
	//print data.
	void printStudent() const;
};



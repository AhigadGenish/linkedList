#include "List.h"

void  List::setHead(Node* head)
{
	this->_head = head;
}
void List::swap(Node* otherNode, Node* anyNode) 
{

	if (otherNode->getPrev() == NULL)
	{
		otherNode->setNext(anyNode->getNext());
		anyNode->setPrev(NULL);
		anyNode->getNext()->setPrev(otherNode);
		anyNode->setNext(this->getHead());
		otherNode->setPrev(anyNode);

		return;
	}
	else if (anyNode->getPrev() == NULL)
	{
		anyNode->setNext(otherNode->getNext());
		otherNode->setPrev(NULL);
		otherNode->getNext()->setPrev(anyNode);
		otherNode->setNext(this->getHead());
		anyNode->setPrev(otherNode);

		return;
	}
	else if (otherNode->getNext() == NULL)
	{
		anyNode->setNext(NULL);
		anyNode->getPrev()->setNext(otherNode);
		otherNode->setNext(anyNode);
		otherNode->setPrev(anyNode->getPrev());
		anyNode->setPrev(otherNode);
		return;
		
	}
	else if (anyNode->getNext() == NULL)
	{
		otherNode->setNext(NULL);
		otherNode->getPrev()->setNext(anyNode);
		anyNode->setNext(otherNode);
		anyNode->setPrev(otherNode->getPrev());
		otherNode->setPrev(anyNode);
		return;
	}
	else
	{
		otherNode->setNext(anyNode->getNext());
		anyNode->getNext()->setPrev(otherNode);
		anyNode->setNext(otherNode);
		otherNode->getPrev()->setNext(anyNode);
		anyNode->setPrev(otherNode->getPrev());
		otherNode->setPrev(anyNode);
		return;
	}

}
Node* List::getTail() const
{
	
	Node* temp = this->getHead();
	if (temp == NULL)
		return NULL;
	while (temp->getNext())
	{
		temp = temp->getNext();
	}
	return temp;

}
void List::sortListByGpa() 
{
	bool flag = false;
	int len = this->getSize();
	if (this->getHead() == NULL)
	{
		cout << "The list is empty , no sorted " << endl;
		return;
	}
	if (len == 1)
	{
		cout << " only one element in the list" << endl;
		return;
	}

	for (int i = 0;i < len - 1;i++)
	{
		

		
		for (int j = 0;j < len - i - 1;j++)
		{
			flag = false;

			if (this->getHead()->getNext() != NULL)
			{
				if (this->getHead()->getStudent().getGpa() < this->getHead()->getNext()->getStudent().getGpa())
				{
					swap(this->getHead(), this->getHead()->getNext());
					flag = true;
				}
				

			}
			else break;

			if (!flag)
				this->_head = this->getHead()->getNext();


		}
		while (this->getHead()->getPrev())
		{
			this->_head = this->getHead()->getPrev();
		}
		
		
	
	}
	while (this->getHead()->getPrev())
		this->_head = this->getHead()->getPrev();



}

void  List::insertFirst(const Student& st)
{
	Node* temp = new Node(st,NULL,NULL);
	if (this->getHead() == NULL)
	{	this->setHead(temp);
		return;
	}
		
	
	temp->setNext(this->getHead());
	this->getHead()->setPrev(temp);
	this->setHead(temp);
	

}
void  List::insertLast(const Student& st)
{
	Node* temp = new Node(st,NULL,NULL);
	if (this->getHead() == NULL)
	{
		this->setHead(temp);
		return;
	}


	Node* newNode = this->getTail();
	newNode->setNext(temp);
	temp->setPrev(newNode);
	


}
void List:: insertSortedByGpa(const Student& st)
{
	
	this->insertFirst(st);
	sortListByGpa();
	
}
void  List::removeNode(string  id)
{
	Node* node = findNode(id);
	if (node == NULL)
	{
		cout << "can't find this student" << endl;
		return;
	}
	if (this->getSize() == 1)
	{
		delete this->_head;
		this->_head = NULL;
		cout << "The student " <<id<<" is removed from the list"<< endl;
		return;
	}
	if(node->getNext() == NULL )
	{
		node ->getPrev()->setNext(NULL);
		delete node;
		cout << "The student " << id << " is removed from the list" << endl;
		return;
	}
	else if (node->getPrev() == NULL)
	{
		this->setHead(this->getHead()->getNext());
		this->getHead()->setPrev(NULL);
		delete node;
		cout << "The student " << id << " is removed from the list" << endl;
		return;

	}
	else
	{
		node->getNext()->setPrev(node->getPrev());
		node->getPrev()->setNext(node->getNext());
		delete node;
		cout << "The student " << id << " is removed from the list" << endl;
		return;

	}



}
Node* List:: findNode(string id) const
{
	Node* temp = this->getHead();
	while (temp)
	{
		if (temp->getStudent().getId() == id)
			return temp;
		temp = temp->getNext();
	}
	cout << "The student is not in list" << endl;
	return NULL;

	
}
int List::getSize() const
{
	int size = 0;
	Node* temp = this->getHead();
	if (temp == NULL)
		return 0;
	while (temp)
	{
		size += 1;
		temp = temp->getNext();
	}
	return size;
}
void List::printList() const
{
	cout << "The student list:" << endl;
	Node* temp = this->getHead();
	if (temp == NULL)
	{
		cout << "List is empty" << endl;
		return;
	}
	while (temp != NULL)
	{
		temp->printNode();
		cout << "**********" << endl;
		temp = temp->getNext();
		
	}
}
List::List(const List& other)
{
	Node*  temp = other._head;
	this->_head = NULL;

	while (temp)
	{
		this->insertLast(temp->getStudent());
		temp = temp->getNext();
	}
}
List::List(Node* head)
{
	this->setHead(head);
}
List::~List()
{
	while (this->getHead())
		this->removeNode(this->getHead()->getStudent().getId());
}

#include "List.h"

void  List::setHead(Node* head)
{
	this->_head = head;
}
void List::genericSwap(Node* otherNode, Node* anyNode)
{

int otherNodeLocation = this->findLocationNode(otherNode->getStudent().getId());
int anyNodeLocation = this->findLocationNode(anyNode->getStudent().getId());
int distance = otherNodeLocation - anyNodeLocation;

if (distance == 1) {
	Node temp = *(anyNode);
	anyNode->setNext(otherNode->getNext());
	if (otherNode->getNext() != NULL)
		otherNode->getNext()->setPrev(anyNode);
	otherNode->setNext(anyNode);
	if (anyNode->getPrev() != NULL)
		anyNode->getPrev()->setNext(otherNode);
	otherNode->setPrev(temp.getPrev());
	anyNode->setPrev(otherNode);

}
else if (distance == -1) {
	Node temp = *(otherNode);
	otherNode->setNext(anyNode->getNext());
	if (anyNode->getNext() != NULL)
		anyNode->getNext()->setPrev(otherNode);
	anyNode->setNext(otherNode);
	if (otherNode->getPrev() != NULL)
		otherNode->getPrev()->setNext(anyNode);
	anyNode->setPrev(temp.getPrev());
	otherNode->setPrev(anyNode);

}
else if (distance > 1) {
	Node temp1 = *(anyNode);
	Node temp2 = *(otherNode);
	anyNode->setNext(otherNode->getNext());
	if (otherNode->getNext() != NULL)
		otherNode->getNext()->setPrev(anyNode);
	otherNode->setNext(temp1.getNext());
	if (anyNode->getPrev() != NULL)
		anyNode->getPrev()->setNext(otherNode);
	temp1.getNext()->setPrev(otherNode);
	anyNode->setPrev(otherNode->getPrev());
	otherNode->setPrev(temp1.getPrev());
	temp2.getPrev()->setNext(anyNode);



}
else {
	Node temp1 = *(otherNode);
	Node temp2 = *(anyNode);
	otherNode->setNext(anyNode->getNext());
	if (anyNode->getNext() != NULL)
		anyNode->getNext()->setPrev(otherNode);
	anyNode->setNext(temp1.getNext());
	if (otherNode->getPrev() != NULL)
		otherNode->getPrev()->setNext(anyNode);
	temp1.getNext()->setPrev(anyNode);
	otherNode->setPrev(anyNode->getPrev());
	anyNode->setPrev(temp1.getPrev());
	temp2.getPrev()->setNext(otherNode);


}
while (this->getHead()->getPrev())
this->_head = this->getHead()->getPrev();

}

void List :: sortSwap(Node* otherNode, Node* nextOtherNode)
{

	int otherNodeLocation = this->findLocationNode(otherNode->getStudent().getId());
	int anyNodeLocation = this->findLocationNode(nextOtherNode->getStudent().getId());
	int distance = otherNodeLocation - anyNodeLocation;

	if (distance == 1) {
		Node temp = *(nextOtherNode);
		nextOtherNode->setNext(otherNode->getNext());
		if (otherNode->getNext() != NULL)
			otherNode->getNext()->setPrev(nextOtherNode);
		otherNode->setNext(nextOtherNode);
		if (nextOtherNode->getPrev() != NULL)
			nextOtherNode->getPrev()->setNext(otherNode);
		otherNode->setPrev(temp.getPrev());
		nextOtherNode->setPrev(otherNode);
		return;

	}
	else {
		Node temp = *(otherNode);
		otherNode->setNext(nextOtherNode->getNext());
		if (nextOtherNode->getNext() != NULL)
			nextOtherNode->getNext()->setPrev(otherNode);
		nextOtherNode->setNext(otherNode);
		if (otherNode->getPrev() != NULL)
			otherNode->getPrev()->setNext(nextOtherNode);
		nextOtherNode->setPrev(temp.getPrev());
		otherNode->setPrev(nextOtherNode);
		return;
	}
	
	

	
}

Node* List::getTail() const
{
	
	Node* temp = this->getHead();
	if (temp == NULL)
		return NULL;
	while (temp->getNext())
	{
		temp = temp->getNext();
	}
	return temp;

}
void List::sortListByGpa() 
{
	bool flag = false;
	int len = this->getSize();
	if (this->getHead() == NULL)
	{
		cout << "The list is empty , no sorted " << endl;
		return;
	}
	if (len == 1)
	{
		cout << " only one element in the list" << endl;
		return;
	}

	for (int i = 0;i < len - 1;i++)
	{
		
		for (int j = 0;j < len - i - 1;j++)
		{
			flag = false;

			if (this->getHead()->getNext() != NULL)
			{
				if (this->getHead()->getStudent().getGpa() < this->getHead()->getNext()->getStudent().getGpa())
				{
					sortSwap(this->getHead(), this->getHead()->getNext());
					flag = true;
				}
				

			}
			else break;

			if(!flag)
				this->_head = this->getHead()->getNext();


		}
		while (this->getHead()->getPrev())
		{
			this->_head = this->getHead()->getPrev();
		}
		
		
	
	}
	while (this->getHead()->getPrev())
		this->_head = this->getHead()->getPrev();



}
int List::findLocationNode(string  id)
{
	int location = 0;
	Node* temp = this->getHead();
	while (temp)
	{
		if (temp->getStudent().getId() == id)
			return location;
		temp = temp->getNext();
		location++;

	}
	cout << "The student is not in list" << endl;
	return -1;
	
}
void  List::insertFirst(const Student& st)
{
	Node* temp = new Node(st,NULL,NULL);
	if (this->getHead() == NULL)
	{	this->setHead(temp);
		return;
	}
		
	
	temp->setNext(this->getHead());
	this->getHead()->setPrev(temp);
	this->setHead(temp);
	

}
void  List::insertLast(const Student& st)
{
	Node* temp = new Node(st,NULL,NULL);
	if (this->getHead() == NULL)
	{
		this->setHead(temp);
		return;
	}


	Node* newNode = this->getTail();
	newNode->setNext(temp);
	temp->setPrev(newNode);
	


}
void List:: insertSortedByGpa(const Student& st)
{
	
	this->insertFirst(st);
	sortListByGpa();
	
}
void  List::removeNode(string  id)
{
	Node* node = findNode(id);
	if (node == NULL)
	{
		cout << "can't find this student" << endl;
		return;
	}
	if (this->getSize() == 1)
	{
		delete this->_head;
		this->_head = NULL;
		cout << "The student " <<id<<" is removed from the list"<< endl;
		return;
	}
	if(node->getNext() == NULL )
	{
		node ->getPrev()->setNext(NULL);
		delete node;
		cout << "The student " << id << " is removed from the list" << endl;
		return;
	}
	else if (node->getPrev() == NULL)
	{
		this->setHead(this->getHead()->getNext());
		this->getHead()->setPrev(NULL);
		delete node;
		cout << "The student " << id << " is removed from the list" << endl;
		return;

	}
	else
	{
		node->getNext()->setPrev(node->getPrev());
		node->getPrev()->setNext(node->getNext());
		delete node;
		cout << "The student " << id << " is removed from the list" << endl;
		return;

	}



}
Node* List:: findNode(string id) const
{
	Node* temp = this->getHead();
	while (temp)
	{
		if (temp->getStudent().getId() == id)
			return temp;
		temp = temp->getNext();
	}
	cout << "The student is not in list" << endl;
	return NULL;

	
}
int List::getSize() const
{
	int size = 0;
	Node* temp = this->getHead();
	if (temp == NULL)
		return 0;
	while (temp)
	{
		size += 1;
		temp = temp->getNext();
	}
	return size;
}
void List::printList() const
{
	cout << "The student list:" << endl;
	Node* temp = this->getHead();
	if (temp == NULL)
	{
		cout << "List is empty" << endl;
		return;
	}
	while (temp != NULL)
	{
		temp->printNode();
		cout << "**********" << endl;
		temp = temp->getNext();
		
	}
}
List::List(const List& other)
{
	Node*  temp = other._head;
	this->_head = NULL;

	while (temp)
	{
		this->insertLast(temp->getStudent());
		temp = temp->getNext();
	}
}
List::List(Node* head)
{
	this->setHead(head);
}
List::~List()
{
	while (this->getHead())
		this->removeNode(this->getHead()->getStudent().getId());
}

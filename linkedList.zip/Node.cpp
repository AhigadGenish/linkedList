#include "Node.h"

void Node:: setNext(Node* next)
{

	this->_next = next;
}
void  Node::setPrev(Node* prev)
{
	
	this->_previous = prev;
	
}
void Node::setStudent(const Student& student)
{
	this->_student.setStudent(student.getName(),student.getId(),student.getGpa());
}
void Node::setNode(Node* next, Node* prev,const Student student)
{
	 setNext(next);
	 setPrev(prev);
	 setStudent(student);
}
void Node::printNode()const
{
	if (this == NULL)
	{
		cout << "Node is NULL" << endl;
		return;
	}


	this->getStudent().printStudent();
	if (this->getNext() != NULL)
		cout << "Next is :" << this->getNext()->getStudent().getName() << endl;
	else
		cout << "Next is : NULL" << endl;
	if (this->getPrev() != NULL)
		cout << "Previous is :" << this->getPrev()->getStudent().getName() << endl;
	else
		cout << "Previous is : NULL" << endl;
}
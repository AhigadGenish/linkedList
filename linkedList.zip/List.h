#include "Node.h"
class List
{
	Node* _head;
	
public:
	//getters.
	Node* getHead() const
	{return this->_head;}
	Node* getTail() const;
	int  getSize() const;
	//setters and isert node.
	void setHead(Node* head);
	void insertFirst(const Student &st);
	void insertLast(const Student& st);
	void insertSortedByGpa(const Student& st);
	//swap nodes.
	void swap(Node* otherNode, Node* anyNode);
	//sort list by grades.
	void sortListByGpa();
	//remove node by id .
	void removeNode(string id);
	//print list.
	void printList() const;
	// find node by id.
	Node* findNode(string id) const;
	//constructors and destructor.
	List(Node* head = NULL);
	List(const List& other);
	~List();

};


#include "student.h"

class Node
{
	Student _student;
	Node* _next;
	Node* _previous;
public:
	//getters.
	Student getStudent()const 
	{ return this->_student;}
	Node* getNext() const
	{return this->_next;}
	Node* getPrev() const
	{return this->_previous;}
	//setters and constructors.
	void setStudent(const Student& student);
	void setNext(Node* next);
	void setPrev(Node* prev);
	void setNode(Node* next, Node* prev,Student student);

	Node(const Student& s,Node * next = NULL ,Node* prev = NULL) :_student(s) {
		this->setNext (next);
		this->setPrev(prev);
	}
	// print Node.
	void printNode()const;
};


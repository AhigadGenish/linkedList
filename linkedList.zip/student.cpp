#include "student.h"
void Student :: setName(string name)
{
	this->_name = name;
}
void Student:: setId(string id)
{
	this->_id = id;
}
void Student::setGpa(int grade)
{
	this->_gpa = grade;

}
void Student:: setStudent(string name, string id,int grade)
{
	setName(name);
	setId(id);
	setGpa(grade);
}

Student:: Student(const Student& student)
{
	this->setStudent(student.getName(), student.getId(), student.getGpa());
}
void Student::printStudent() const
{
	cout << "Name:" << this->getName() << endl;
	cout << "Id:" << this->getId() << endl;
	cout << "GPA:" << this->getGpa() << endl;
}